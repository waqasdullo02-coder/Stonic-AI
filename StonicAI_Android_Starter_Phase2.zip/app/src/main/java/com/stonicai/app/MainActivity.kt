package com.stonicai.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val pickedVideos = mutableStateListOf<Uri>()
    private val picker = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(100)
    ) { uris ->
        uris.forEach { uri -> if (!pickedVideos.contains(uri)) pickedVideos.add(uri) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var tab by remember { mutableIntStateOf(0) }
                Scaffold(
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                                icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                                icon = { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Library") })
                            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                                icon = { Icon(Icons.Default.Schedule, null) }, label = { Text("Schedule") })
                        }
                    }
                ) { padding ->
                    when (tab) {
                        0 -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                            Text("STONIC AI", style = MaterialTheme.typography.headlineLarge)
                            Spacer(Modifier.height(12.dp))
                            Text("Your social video workspace")
                            Spacer(Modifier.height(24.dp))
                            Text("Videos in library: ${pickedVideos.size}")
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { tab = 1 }) { Text("Open Video Library") }
                        }
                        1 -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Video Library", style = MaterialTheme.typography.headlineSmall)
                                FilledTonalIconButton(onClick = {
                                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                                }) { Icon(Icons.Default.Add, "Add videos") }
                            }
                            Text("Select multiple videos from your phone.")
                            Spacer(Modifier.height(12.dp))
                            if (pickedVideos.isEmpty()) Text("No videos selected yet.")
                            LazyColumn {
                                items(pickedVideos) { uri ->
                                    ListItem(
                                        headlineContent = { Text(uri.lastPathSegment ?: "Selected video") },
                                        supportingContent = { Text(uri.toString(), maxLines = 1) },
                                        trailingContent = {
                                            TextButton(onClick = { pickedVideos.remove(uri) }) { Text("Remove") }
                                        }
                                    )
                                    HorizontalDivider()
                                }
                            }
                        }
                        else -> Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                            Text("Schedule", style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.height(12.dp))
                            Text("Scheduling and automatic publishing will be added in a later phase.")
                        }
                    }
                }
            }
        }
    }
}
