# Stonic AI — ابتدائی Android پروجیکٹ

یہ Phase 2 starter ہے۔ اس میں:
- Home، Library اور Schedule کی بنیادی اسکرینیں
- فون سے بیک وقت متعدد ویڈیوز منتخب کرنے کا Photo Picker
- منتخب ویڈیوز کی عارضی فہرست

**ابھی شامل نہیں:** TikTok publishing، Instagram downloader، AI captions، video editing، cloud backend یا مکمل scheduler۔

## APK بنانا
GitHub Actions workflow دستیاب ہے۔ Repository میں فائلیں اپلوڈ کرنے کے بعد Actions ٹیب سے workflow چلائیں۔
